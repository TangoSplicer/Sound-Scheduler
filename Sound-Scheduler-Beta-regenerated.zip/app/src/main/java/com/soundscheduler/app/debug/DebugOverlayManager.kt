package com.soundscheduler.app.debug

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import com.soundscheduler.app.R
import com.soundscheduler.app.BuildConfigimport com.soundscheduler.app.utils.UsageAnalyticsManager
import java.lang.ref.WeakReference

@SuppressLint("StaticFieldLeak")  // we only hold a weak ref to the view
object DebugOverlayManager {

    private var overlayViewRef: WeakReference<View>? = null
    private var windowManager: WindowManager? = null

    @JvmStatic
    @Suppress("unused")  // called by debug build
    fun showOverlay(context: Context) {
        if (!BuildConfig.BETA) return

        val appCtx = context.applicationContext
        if (overlayViewRef?.get() == null) {
            windowManager = appCtx.getSystemService(Context.WINDOW_SERVICE) as WindowManager

            // Inflate with a dummy root to resolve layout params
            val parent = FrameLayout(appCtx)
            val view = LayoutInflater.from(appCtx)
                .inflate(R.layout.overlay_debug, parent, false)

            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                android.graphics.PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.END
            }

            windowManager?.addView(view, params)
            overlayViewRef = WeakReference(view)
        }

        overlayViewRef?.get()?.let { view ->
            val tv = view.findViewById<TextView>(R.id.debugTextView)
            tv.text = UsageAnalyticsManager.getSummary(context)
        }
    }

    @JvmStatic
    @Suppress("unused")  // called by debug build
    fun hideOverlay() {
        overlayViewRef?.get()?.let { view ->
            windowManager?.removeView(view)
        }
        overlayViewRef = null
    }

    @Suppress("unused")
    fun showToast(context: Context, message: String) {
        if (BuildConfig.BETA) {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }
    }
}
