# Sound Scheduler Changelog

## [0.9.0] - Beta Release
- Free and Premium split implemented
- Location-based routines
- Calendar-based routines
- Ads for free users (minimally invasive)
- Routine limits: 3 free, 10 premium
- Offline backup and restore
- Routine templates
- Dark/AMOLED themes
- Widget support for premium
- Archive completed routines
- Smart notifications on triggers
- Stability improvements
- Ready for Play Store beta distribution

---

Next:
- UI refinements
- User feedback integration
- Optimization for power efficiency